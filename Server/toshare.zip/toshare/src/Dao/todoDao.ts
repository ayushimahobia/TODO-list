import Todo from "../models/todo"
import { ITodo } from "../types/todo";
import { NextFunction } from "express";

export default class TodoDao{
    private todoModel = Todo;
    constructor(){}
    public getTodosdao = async(userId:string)=>{
        return await this.todoModel.find({userId:userId});
    }
    public addTododao = async(userId:string,name:string,des:string,stat:boolean)=>{
        const toadd  = new Todo ({
            name : name,
            description : des,
            status : stat,
        })
        const newtodo :ITodo = await toadd.save();
        const alltodos :ITodo[] = await Todo.find();
        return await this.todoModel.find({userId:userId}) 
    }
    public updateTododao = async(userId:string,body:any)=>{
      const updatelist: ITodo| null = await Todo.findOneAndUpdate({ _id: userId },body) 
      const alltodo: ITodo[] = await Todo.find()
      const todoUpdated = new Todo({
        messgage :"Todo Updated",
        Todo : updatelist,
        todos : alltodo,
      })
      return await this.todoModel.find({userId:userId})
    }
    public deleteTododao = async(userId:string)=>{
      return await Todo.deleteOne({ _id: userId })
    }

}