import userService from "../Services/userservices";
import bcrypt from "bcrypt";
import user from "../models/user";

export default class Userdao{
    private usermodel = user
    constructor(){}
    public signupdao = async(username:string,email:string,password:string)=>{
        const existingUser = await user.findOne({ email: email });
        if (existingUser) {
            return await this.usermodel.findOne({email:email});
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = await user.create({
            email: email,
            password: hashedPassword,
            username: username,
        });
        return await newUser.save();
    }
    public logindao = async(username:string)=>{
        return await this.usermodel.findOne({username:username})
    }
    
}