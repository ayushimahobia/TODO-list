import TodoDao from "../Dao/todoDao";
import createHttpError from "http-errors";
import user from "../models/user";

export default class TodoListService{
  private todoDao = new TodoDao()
  public getTodosservices = async(userId:string) =>{
     if(!userId){
        throw createHttpError(404,"login required");
     }
     return await this.todoDao.getTodosdao(userId.toString())
  }
  public addTodoservices = async(userId:string,name:string,des:string,stat:boolean)=>{
      if(!userId){
        throw createHttpError(404,"login or signup required")
      }
      return await this.todoDao.addTododao(userId,name,des,stat);
  }
  public updateTodoservices = async(userId:string,body:string)=>{
      if(!userId){
        throw createHttpError(404,"invalid id")
      }
      return await this.todoDao.updateTododao(userId,body);
  }
  public deleteTodoservices = async(userId:string)=>{
      if(!userId){
        throw createHttpError(404,"invalid id")
      }
      return await this.todoDao.deleteTododao(userId);
  }
}