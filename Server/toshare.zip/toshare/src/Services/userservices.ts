import Userdao from "../Dao/userdao";
import createHttpError from "http-errors";
import user from "../models/user";

export default class userService {
   private userdao = new Userdao();
   public signup = async(username:string,email:string,password:string)=>{
      if(!username || !email || !password){
        throw createHttpError (404, "Please fill all fields")
      }
      return await this.userdao.signupdao(username,email,password);
   }
   
   public login = async(username:string,email:string,password:string)=>{
       if(!email || !password){
        throw createHttpError(404,"Invalid credentials")
       }
          return  await this.userdao.logindao(username);
   }
}