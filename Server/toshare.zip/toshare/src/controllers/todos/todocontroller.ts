import { Response, Request } from "express";
import { ITodo } from "../../types/todo";
import Todo from "../../models/todo";
import user from "../../models/user";
import TodoListService from "../../Services/todo.service";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import verifyToken from "../../middleware/auth";

class TodoList {
  private addServices = new TodoListService();
  public getTodos = async (req: Request, res: Response) => {
    const userId = req.params.id;
    const tokennew = req.headers.authorization;
    try {
      const todos = await this.addServices.getTodosservices(userId);
      res.status(200).json({ todos });
    } catch (error) {
      throw error;
    }
  };
  public addTodo = async (req: Request, res: Response) => {
    const val = req.body as Pick<ITodo, "name" | "description" | "status">;
    const userId = req.body.id;
    const userName = val.name;
    const des = val.description;
    const stat = val.status;
    try {
      const todo = await this.addServices.addTodoservices(
        userId,
        userName,
        des,
        stat
      );
      res.status(200).json({ messsge: "New Todo Added", todo });
    } 
    catch (error) {
      throw error;
    }
  };

  public updateTodo = async (req: Request, res: Response) => {
    const {
      params: { id },
      body,
    } = req;
    try {
      const updateTodo = await this.addServices.updateTodoservices(id, body);
      res.status(200).json({
        messgage: "Todo Updated",
        updateTodo
      });
    } catch (error) {
      res.status(400).json(error);
      throw error;
    }
  };
  public deleteTodo = async (req: Request, res: Response) => {
    try {
      const DelteTodo = await this.addServices.deleteTodoservices(req.params.id)
    } catch (error) {
      throw error;
    }
  };
}
export default TodoList;

// controller 
