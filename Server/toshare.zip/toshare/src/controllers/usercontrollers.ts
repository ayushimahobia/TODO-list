import { Response, Request } from "express";
import user from "../models/user";
import userService from "../Services/userservices";
import verifyToken from "../middleware/auth";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";



const jwtSecret = "4715aed3c946f7b0a38e6b534a9583628d84e96d10fbc04700770d572af3dce43625dd"

export default class Userlist {
    private userservices = new userService();
    private verifyController = new verifyToken();
    public signup = async (req: Request, res: Response) => {
      const { username, email, password } = req.body;
      try {
          const checkSignup = await this.userservices.signup(username,email,password);
          const existingUser = await user.findOne({ email: email });
          if (existingUser) {
              return res.status(400).json({ message: "User already exists" });
          }
        //   const hashedPassword = await bcrypt.hash(password, 10);
        //   const newUser = await user.create({
        //       email: email,
        //       password: hashedPassword,
        //       username: username,
        //   });
  
          if (!checkSignup) {
              return res.status(500).json({ message: "User creation failed" });
          }
          const maxAge = 3 * 60 * 60;
          const token = jwt.sign(
              { email: checkSignup.email, id: checkSignup._id },
              jwtSecret,
              {
                  expiresIn: maxAge,
              }
          );
          res.cookie("jwt", token, {
              httpOnly: true,
              maxAge: maxAge * 1000,
          });
          res.status(201).json({ user: checkSignup, token });
      } catch (error) {
          console.log(error);
          res.status(500).json({ message: "Something went wrong" });
      }
  };
  
    public signin = async (req: Request, res: Response) => {
      const { email, password } = req.body;
      try {
        const existingUser = await user.findOne({ email: email });
        if (!existingUser) {
          res.status(404).json({ message: "User not found" });
          return;
        }
        const matchPassword = await bcrypt.compare(
          password,
          existingUser.password
        );
        const maxAge = 3*60*60;
        if (!matchPassword) {
          res.status(400).json({ message: "Invalid Password" });
        }
        const token = jwt.sign(
          { email: existingUser.email, id: existingUser._id },
          jwtSecret,
          {
            expiresIn : maxAge,
          }
        );
        const result = {
            email : existingUser.email,
            id : existingUser.id,
            token : `Bearer ${token}`
        }
        res.cookie("jwt",token,{
          httpOnly:true,
          maxAge: maxAge*1000,
        })
        res.status(200).json({...result,message:"you are logged in"});
      } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Something went wrong" });
      }
    };
    public logout = async (req: Request, res: Response): Promise<void> => {
      res.clearCookie("refreshToken");
      res.status(200).json({ success: true, message: "LogOut SuccesFully" });
    };
  
}