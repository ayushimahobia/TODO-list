import { config } from 'dotenv';
import { Request, Response, NextFunction } from 'express';
import { IncomingHttpHeaders } from 'http';
import jwt from "jsonwebtoken";

const jwtSecret = "4715aed3c946f7b0a38e6b534a9583628d84e96d10fbc04700770d572af3dce43625dd"


export default class verifyToken{
    public verifyuser = async(req:Request,res:Response,next:NextFunction)=>{
        const token = req.headers["authorization"];
        if(!token){
            return res.status(403).json({message:"Token not present"});
        }
        const splitToken = token.split(" ")[1];
        jwt.verify(splitToken, jwtSecret, (err, decoded) => {
            console.log("verifying");
            if (err) return res.status(403).json({message:"token not verified"}); 
            console.log(decoded); 
            next();
          });
    }
}