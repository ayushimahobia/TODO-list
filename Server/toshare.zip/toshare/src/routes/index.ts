import express, { Router } from "express";
import TodoList from "../controllers/todos/todocontroller";
import Userlist from "../controllers/usercontrollers";
import verifyToken from "../middleware/auth";


class userRoutes{
    public router:Router;
    private control: TodoList = new TodoList();
    private userControl :Userlist = new Userlist(); 
    private auth : verifyToken = new verifyToken();
    constructor(){
        this.router = express.Router();
        this.todoRoutes();
    }
    public todoRoutes():void{
    this.router.get("/todos",this.control.getTodos)
    this.router.post("/add-todo",this.control.addTodo)
    this.router.put("/update-todo/:id",this.control.updateTodo)
    this.router.delete("/delete-todo/:id",this.control.deleteTodo)
    this.router.post("/signup",this.userControl.signup)
    this.router.post("/signin",this.userControl.signin)
    this.router.post("/logout",this.userControl.logout)
    }
}
export default userRoutes;


